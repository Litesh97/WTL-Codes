/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import com.opensymphony.xwork2.ActionSupport;
/**
 *
 * @author mohit
 */
public class Calc extends ActionSupport {
    
    private int x, y, result;
    
    public void setX(int x) {
        System.out.println("Hey set x");
        this.x = x;
    }
    public int getX() {
        System.out.println("Hey get x");
        return x;
    }
    
    public void setY(int y) {
        System.out.println("Hey set y");
        this.y = y;
    }
    public int getY() {
        System.out.println("Hey get y");
        return y;
    }
    public void setResult(int result) {
        System.out.println("Hey set result");
        this.result = result;
    }
    public int getResult() {
        System.out.println("Hey get result");
        return result;
    }
    
    public String execute() {
        System.out.println("Hey execute");
        result = x+y;
        return "success";
    }
}
