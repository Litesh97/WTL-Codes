/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import com.opensymphony.xwork2.ActionSupport;
/**
 *
 * @author aniket
 */
public class program extends ActionSupport {
    
    private String id, name, dept, sal;
    
    public String execute() {
        System.out.println("execute");
        if(name != null){
            return "success";
        }
        else
        {
            return "error";
        }
    }
    public void setId(String id)
    {
        System.out.println("set id");
        this.id = id;
    }
    public void setName(String name)
    {
        System.out.println("set name");
        this.name = name;
    }
    public void setDept(String dept)
    {
        System.out.println("set dept");
        this.dept = dept;
    }    
    public void setSal(String sal)
    {
        System.out.println("set sal");
        this.sal = sal;
    }
    
    public String getId()
    {
        System.out.println("get id");
        return id;
    }
    public String getName()
    {
        System.out.println("get name");
        return name;
    }
    public String getDept()
    {
        System.out.println("get dept");
        return dept;
    }
    public String getSal()
    {
        System.out.println("get sal");
        return sal;
    }
}
