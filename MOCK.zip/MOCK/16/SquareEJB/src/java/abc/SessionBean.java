/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc;

import javax.ejb.Stateless;

/**
 *
 * @author mohit
 */
@Stateless
public class SessionBean implements SessionBeanRemote {

    @Override
    public int showSquare(String num) {
        int a = Integer.parseInt(num);
        a= a*a;
        return a;
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
