/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

import javax.ejb.Stateless;

/**
 *
 * @author mohit
 */
@Stateless
public class SessionBean implements SessionBeanRemote {

    @Override
    public String showName(String name) {
        return name;
    }
    
    @Override
    public String showId(String id) {
        return id;
    }

    @Override
    public String showCity(String city) {
        return city;
    }

    @Override
    public String showPhone(String phone) {
        return phone;
    }
}
