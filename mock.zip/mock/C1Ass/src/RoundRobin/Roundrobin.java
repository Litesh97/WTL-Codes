package RoundRobin;

import java.util.ArrayList;
import java.util.Scanner;

class Process {
	int at,bt,rem_bt,wt,ta;
	
	public Process()
	{
		
	}
	
}



public class Roundrobin {
	Scanner sc=new Scanner(System.in);
	ArrayList<Process> process=new ArrayList<>();
	int n,quantamtime;
	
	public void input()
	{
		System.out.println("enter number of process");
		n=sc.nextInt();
		System.out.println("Enter burst and arrival time");
		for(int i=0;i<n;i++)
		{
			int bt=sc.nextInt();
			int at=sc.nextInt();
			Process p=new Process();
			p.bt=bt;
			p.at=at;
			System.out.println("hey");
			p.rem_bt=bt;
			process.add(p);
		}
		System.out.println("Enter quantam time");
		quantamtime=sc.nextInt();
	}
	
	public void cal()
	{
		
		System.out.println("bye");
		int t=0;
		while(true)
		{
			boolean done=true;
			
			for(int i=0;i<n;i++)
			{
				if(process.get(i).rem_bt>0)
				{
					done=false;
					if(process.get(i).rem_bt>quantamtime)
					{
						t=t+quantamtime;
						process.get(i).rem_bt=process.get(i).rem_bt-quantamtime;
					}
					else
					{
						t=t+process.get(i).rem_bt;
						process.get(i).wt=t-process.get(i).bt;
						process.get(i).rem_bt=0;
					}
				}
			}
			
			if(done==true)
			{
				break;
			}
		}
		
		float avgwt=0,avgta=0;
		for(int i=0;i<n;i++)
		{
			avgwt=avgwt+process.get(i).wt;
		}
		
		for(int i=0;i<n;i++)
		{
			process.get(i).ta=process.get(i).wt+process.get(i).bt;
		}
		
		for(int i=0;i<n;i++)
		{
			avgta=avgta+process.get(i).ta;
		}
		
		avgwt=avgwt/n;
		avgta=avgta/n;
		System.out.println(avgwt);
		
		
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Roundrobin r=new Roundrobin();
		r.input();
		r.cal();
	}

}
