package Sjf;

import java.util.ArrayList;
import java.util.Scanner;

class Process 
{
	int bt,at,wt,ta,ct,kt,f;

	public Process(int bt, int at, int wt, int ta, int ct, int kt, int f) {
		super();
		this.bt = bt;
		this.at = at;
		this.wt = wt;
		this.ta = ta;
		this.ct = ct;
		this.kt = kt;
		this.f = f;
	}

	public Process() {
		// TODO Auto-generated constructor stub
	}
	
}



public class Sjf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int st=0,tot=0;
		float avgw=0,avgt=0;
		Scanner sc= new Scanner(System.in);
		int n;
		System.out.println("Enter number of process");
		n=sc.nextInt();
		ArrayList<Process> list=new ArrayList<>();
		
		for(int i=0;i<n;i++)
		{
			System.out.println("enter burst time for process"+i+1);
			int but=sc.nextInt();
			System.out.println("enter arrival time for process"+i+1);
			int arr=sc.nextInt();
			Process p=new Process();
			p.bt=but;
			p.at=arr;
			p.kt=but;
			p.f=0;
			list.add(p);
		}
		
		while(true)
		{
			int min=999,c=n;
			if(tot==n)
				break;
			
			for(int i=0;i<n;i++)
			{
				if(list.get(i).at<=st && list.get(i).f!=1 && list.get(i).bt<min)
				{
					min=list.get(i).bt;
					c=i;
				}
			}
			
			if(c==n)
			{
				st++;
			}
			else
			{
				System.out.println(c);
				list.get(c).bt--;
				st++;
				if(list.get(c).bt==0)
				{
					list.get(c).f=1;
					tot=tot+1;
					list.get(c).ct=st;
				}
			}
			
		}
		
		for(int i=0;i<n;i++)
		{
			list.get(i).ta=list.get(i).ct-list.get(i).at;
			list.get(i).wt=list.get(i).ta-list.get(i).kt;
			avgw=avgw+list.get(i).wt;
			avgt=avgt+list.get(i).ta;
		}
		
		System.out.println("pid  arrival  burst  complete turn waiting");
	    for(int i=0;i<n;i++)
	    {
	    	System.out.println(i +"\t"+ list.get(i).at+"\t"+  list.get(i).kt +"\t"+  list.get(i).ct +"\t"+  list.get(i).ta +"\t"+list.get(i).wt );
	    }
	    
	    System.out.println("\naverage tat is "+ (avgt/(float)n));
	    System.out.println("average wt is "+ (avgw/(float)n));
		
		
	}
	
	
	
	

}
