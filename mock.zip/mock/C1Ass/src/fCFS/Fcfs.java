
import java.util.*;


import java.io.*;

class Sorting implements Comparator<Process>
{

	@Override
	public int compare(Process o1, Process o2) {
		// TODO Auto-generated method stub
		return o1.arrival - o2.arrival;
	}

}


	class Process
	{
		int pno;
		int burst;
		int arrival;
		int turnaroundtime;
		int waitingtime;
		int completetime;
		public int getPno() {
			return pno;
		}
		public void setPno(int pno) {
			this.pno = pno;
		}
		public int getBurst() {
			return burst;
		}
		public void setBurst(int burst) {
			this.burst = burst;
		}
		public int getArrival() {
			return arrival;
		}
		public void setArrival(int arrival) {
			this.arrival = arrival;
		}
		public int getTurnaroundtime() {
			return turnaroundtime;
		}
		public void setTurnaroundtime(int turnaroundtime) {
			this.turnaroundtime = turnaroundtime;
		}
		public int getWaitingtime() {
			return waitingtime;
		}
		public void setWaitingtime(int waitingtime) {
			this.waitingtime = waitingtime;
		}
		public int getCompletetime() {
			return completetime;
		}
		public void setCompletetime(int completetime) {
			this.completetime = completetime;
		}



		@Override
		public String toString() {
			return "Process [pno=" + pno + ", burst=" + burst + ", arrival=" + arrival + ", turnaroundtime="
					+ turnaroundtime + ", waitingtime=" + waitingtime + ", completetime=" + completetime
					+ ", byarrival="  + "]";
		}


}

public class Fcfs
{
	int n;

	ArrayList<Process> schedule = new ArrayList<Process>();
	Scanner sc=new Scanner(System.in);

	public void getInput()
	{
		System.out.println("Enter number of Processes");
		n=sc.nextInt();

		for(int i=0;i<n;i++)
		{
			System.out.println("Enter arrival time for Process "+(i+1));
			int at=sc.nextInt();
			System.out.println("Enter burst time for Process "+(i+1));
			int bt=sc.nextInt();

			Process p=new Process();
			p.arrival=at;
			p.burst=bt;
			p.pno=i+1;

			schedule.add(p);
		}
		Collections.sort(schedule,new Sorting());  //sorting on basis of arrival tim
		//System.out.println(schedule);

	}

	public void calculate()
	{
		//Collections.sort(schedule, Process.byarrival);
		int totW=0,totT=0;
		Process p0=schedule.get(0);
		p0.completetime=p0.arrival+p0.burst;
		p0.turnaroundtime=p0.completetime-p0.arrival;
		p0.waitingtime=p0.turnaroundtime-p0.burst;
		totT=totT+p0.turnaroundtime;
		totW=totW+p0.waitingtime;
		for(int i=1;i<schedule.size();i++)
		{
			Process p=schedule.get(i);
			Process p1=schedule.get(i-1);

			p.completetime =p1.completetime + p.burst;
			p.turnaroundtime = p.completetime - p.arrival;
			p.waitingtime = p.turnaroundtime - p.burst;

			totW=totW+p.waitingtime;
			totT=totT+p.turnaroundtime;
		}
		System.out.println(totW);
		System.out.println(totT);
		float avgT;
		avgT=totT/(float)schedule.size();
		float avgW=(totW/(float)schedule.size());

		System.out.println("Avg Turn "+avgT);
		System.out.println("Avg Wait "+avgW);

		System.out.println("Pno\tArrival\tBurst\tComplete\tTurn\tWaiting");

		for(int i=0;i<schedule.size();i++)
		{
			Process p=schedule.get(i);
		System.out.println(p.pno+"\t"+p.arrival+"\t"+p.burst+"\t"+p.completetime+"\t"+p.turnaroundtime+"\t"+p.waitingtime);
		}

	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Fcfs f1=new Fcfs();
		f1.getInput();
		f1.calculate();

	}

}
