package priority;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;




class Sorting implements Comparator<Process>
{

	@Override
	public int compare(Process o1, Process o2) {
		// TODO Auto-generated method stub
		return o2.priority - o1.priority;
	}
	
}

class Process
{
	int at,wt,bt,tt,ct,priority;

	public Process(int at, int wt, int bt, int tt, int ct, int priority) {
		super();
		this.at = at;
		this.wt = wt;
		this.bt = bt;
		this.tt = tt;
		this.ct = ct;
		this.priority = priority;
	}

	public Process() {
		// TODO Auto-generated constructor stub
	}

	public int getAt() {
		return at;
	}

	public void setAt(int at) {
		this.at = at;
	}

	public int getWt() {
		return wt;
	}

	public void setWt(int wt) {
		this.wt = wt;
	}

	public int getBt() {
		return bt;
	}

	public void setBt(int bt) {
		this.bt = bt;
	}

	public int getTt() {
		return tt;
	}

	public void setTt(int tt) {
		this.tt = tt;
	}

	public int getCt() {
		return ct;
	}

	public void setCt(int ct) {
		this.ct = ct;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	
	
}

public class Priority {
	
	
	ArrayList<Process> pri = new ArrayList<>();
	Scanner sc=new Scanner(System.in);
	int n;
	float twt=0,tta=0;
	
	
	public void input()
	{
		System.out.println("Enter number of processes");
		n=sc.nextInt();
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter burst time and priority");
			int bt=sc.nextInt();
			int pt=sc.nextInt();
			Process p = new Process();
			p.bt=bt;
			p.at=0;
			p.priority=pt;
			pri.add(p);
		}
		System.out.println("hi");
		Collections.sort(pri, new Sorting());
	}
	
	public void calculate()
	{
		Process p0=pri.get(0);
		p0.ct=p0.at+p0.bt;
		p0.tt=p0.ct-p0.at;
		p0.wt=p0.tt-p0.bt;
		
		tta=tta+p0.tt;
		twt=twt+p0.wt;
		
		
		for(int i=1;i<pri.size();i++)
		{
			Process p1=pri.get(i);
			Process p00=pri.get(i-1);
			
			p1.ct=p00.ct+p1.bt;
			p1.tt=p1.ct-p1.at;
			p1.wt=p1.tt-p1.bt;
			
			tta=tta+p1.tt;
			twt=twt+p1.wt;
			
		}
		
		System.out.println("Waiting avg"+twt/(float)n);
		
		System.out.println("Turn avg"+tta/(float)n);
		
		
		System.out.println("PID\tPriority\tBurst\tCompletion\tTurnAround\tWaiting");
		for(int i=0;i<pri.size();i++)
		{
			Process p=pri.get(i);
			System.out.println("pppp"+"\t"+p.getPriority()+"\t"+p.getBt()+"\t"+p.getCt()+"\t"+p.getTt()+"\t"+p.getWt());
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Priority p=new Priority();
p.input();
p.calculate();
	}

}

/*
package fCFS;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;



 class Process
{
	 int pid;
	 int priority;
	 int burst;
	 int completionTime;
	 int trunAround;
	 int waiting;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getBurst() {
		return burst;
	}
	public void setBurst(int burst) {
		this.burst = burst;
	}
	public int getCompletionTime() {
		return completionTime;
	}
	public void setCompletionTime(int completionTime) {
		this.completionTime = completionTime;
	}
	public int getTrunAround() {
		return trunAround;
	}
	public void setTrunAround(int trunAround) {
		this.trunAround = trunAround;
	}
	public int getWaiting() {
		return waiting;
	}
	public void setWaiting(int waiting) {
		this.waiting = waiting;
	}
	

	Comparator<Process> byPriority = new Comparator<Process>() {
		
		@Override
		public int compare(Process p1, Process p2) {
			// TODO Auto-generated method stub
			int arr1=p1.getPriority();
			int arr2=p2.getPriority();
			
			return arr1-arr2;
		}
	};
	@Override
	public String toString() {
		return "Process [pid=" + pid + ", priority=" + priority + ", burst=" + burst + ", completionTime="
				+ completionTime + ", trunAround=" + trunAround + ", waiting=" + waiting + ", byPriority=" + byPriority
				+ "]";
	}
	 
}
public class Fcfs {
	
	ArrayList<Process> schedule =new ArrayList<>();
	Scanner sc=new Scanner(System.in);
	void getInput()
	{
		System.out.println("Enter No of Processes");
		int n = sc.nextInt();
		for (int i = 0; i <n; i++) {
			System.out.println("Enter the Priority and burst time for Process "+(i+1));
			Process p=new Process();
			p.priority=sc.nextInt();
			p.burst=sc.nextInt();
			p.pid=i+1;
			
			schedule.add(p);
		}
		
	}
	
	void calculate()
	{
		int ttat=0,twt=0;
		float avgTat=0,avgWt=0;
		Process p0=schedule.get(0);
		
		p0.trunAround=p0.burst;
		p0.waiting=p0.trunAround-p0.burst;
		
		ttat=p0.trunAround;
		twt=p0.waiting;
		for (int i = 1; i < schedule.size(); i++) {
			Process p1=schedule.get(i);
			Process p=schedule.get(i-1);
		
			p1.trunAround=p.trunAround+p1.burst;
			p1.waiting=p1.trunAround-p1.burst;
			
			ttat += p1.trunAround;
			twt +=p1.waiting;
		}
		
		System.out.println("PID\tPriority\tBurst\tCompletion\tTurnAround\tWaiting");
		for(int i=0;i<schedule.size();i++)
		{
			Process p=schedule.get(i);
			System.out.println(p.getPid()+"\t"+p.getPriority()+"\t"+p.getBurst()+"\t"+p.getCompletionTime()+"\t"+p.trunAround+"\t"+p.getWaiting());
		}
		avgTat=(float)ttat/schedule.size();
		avgWt=(float)twt/schedule.size();
		System.out.println("Average Turn Around Time"+avgTat);

		System.out.println("Average Waiting Time"+avgWt);
	}
	
	public static void main(String[] args) {
		Fcfs f =new Fcfs();
		f.getInput();
		f.calculate();
	}
}
*/
