package mypackage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class LRU {

	/**
	 * @param args
	 */
	public static void leastRecentlyUsed(ArrayList<Integer> pages, int capacity)
	{
		LinkedList<Integer> queue = new LinkedList<Integer>();
		HashMap<Integer, Integer> leastRecentIndex = new HashMap<Integer, Integer>();
		int pfault = 0, iterator = 0;
		for(int i : pages)
		{
			if(queue.size() < capacity)
			{
				if(!queue.contains(i))
				{
					queue.add(i);
					pfault++;
				}
				leastRecentIndex.put(i, iterator);
			}																					
			else
			{
				if(!queue.contains(i))
				{
					int lru = Integer.MAX_VALUE, val = 0;
					for(int page : queue)
					{
						if(leastRecentIndex.get(page) < lru)
						{
							lru = leastRecentIndex.get(page);
							val = page;
						}
					}
					queue.remove(new Integer(val));
					queue.add(i);
					pfault++;
				}
				leastRecentIndex.put(i, iterator);
			}
			iterator++;
			
			
			System.out.println("Elements of queue at iteration " + iterator);
			for(int element : queue)
			{
				System.out.print(element + " ");
			}
			System.out.println();
		}
		System.out.println("Page faults: " + pfault);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] elements = {2,3,2,1,5,2,4,5,3,2,5,2};
		ArrayList<Integer> pages = new ArrayList<Integer>();
		for(int page : elements)
		{
			pages.add(page);
		}
		
		leastRecentlyUsed(pages, 3);
	}

}
