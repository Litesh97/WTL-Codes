

import java.util.ArrayList;
import java.util.LinkedList;

public class Optimal {

	/**
	 * @param args
	 */
	
	public static void optimalReplace(ArrayList<Integer> pages, int capacity)
	{
		LinkedList<Integer> queue = new LinkedList<Integer>();
		int iteration =0 , page_fault = 0;
		
		for(int  i = 0 ; i < pages.size(); i++)
		{
			if(queue.size() < capacity)
			{
				if(! queue.contains(pages.get(i)))
				{
					queue.add(pages.get(i));
					page_fault++;
				}
			}
			else
			{
				if(!queue.contains(pages.get(i)))
				{
					int farthest_page_index = 0;
					int pre_time = get_future_time(pages, i, queue.get(farthest_page_index));
					int cur_time = get_future_time(pages, i, queue.get(farthest_page_index));
					for(int index = 0; index < queue.size(); index++)
					{
						cur_time = get_future_time(pages, i, queue.get(index));
						if(cur_time == -1)
						{
							pre_time = cur_time;
							farthest_page_index = index;
						}
						else if(pre_time != -1 && cur_time > pre_time )
						{
							pre_time = cur_time;
							farthest_page_index = index;
						}
					}
					queue.remove(farthest_page_index);
					queue.add(pages.get(i));
					page_fault++;
				}
			}
			System.out.println("Elements of queue at iteration " + iteration);
			for(int element : queue)
			{
				System.out.print(element + " ");
			}
			System.out.println();
			iteration++;
			
		}
		System.out.println("Page faults: " + page_fault);
	}
	
	private static int get_future_time(ArrayList<Integer> pages, int cur_page_index, int page)
	{
		for(int i = cur_page_index; i < pages.size();i++)
		{
			if(pages.get(i) == page)
			{
				return i;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		int[] elements = {2,3,2,1,5,2,4,5,3,2,5,2};
		ArrayList<Integer> pages = new ArrayList<Integer>();
		for(int page : elements)
		{
			pages.add(page);
		}
		
		optimalReplace(pages, 3);
	}

}
