import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

class Mnt {
	String name;
	int kp,pp,kpdtp,mdtp;

	public Mnt(String name, int kp, int pp, int kpdtp, int mdtp) {
		super();
		this.name = name;
		this.kp = kp;
		this.pp = pp;
		this.kpdtp = kpdtp;
		this.mdtp = mdtp;
	}

}

class Kpdtab {
	String paramtername,defination;

	public Kpdtab(String paramtername, String defination) {
		super();
		this.paramtername = paramtername;
		this.defination = defination;
	}

}

class Pntab {
	String name,parameter;
	int index;
	public Pntab(String name, String parameter, int index) {
		super();
		this.name = name;
		this.parameter = parameter;
		this.index = index;
	}

}





public class Macro {


	ArrayList<Mnt> mnttab=new ArrayList<>();
	ArrayList<Kpdtab> kpdtab=new ArrayList<>();
	ArrayList<String> mdt=new ArrayList<>();
	ArrayList<Pntab> pntab=new ArrayList<>();


	public void input() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("input.txt"));
		String line="",previous="";
		String name="";
		while((line=br.readLine())!=null)
		{
			//System.out.println(line);
			if(line.equals("MACRO"))
			{
				//System.out.println("me");
				previous="MACRO";
			}
			else if(previous.equals("MACRO"))
			{
				name = updatetable(line);
				previous="";
			}
			else
			{
				//.out.println("going");
				assemble(line,name);
			}
		}


		for(int i=0;i<mdt.size();i++)
		{
			//System.out.println("HIi");
			System.out.println(mdt.get(i));
		}

		System.out.println("\nKPDTAB\n");

		for(int i=0;i<kpdtab.size();i++)
		{
			System.out.println(" "+kpdtab.get(i).paramtername+"  "+kpdtab.get(i).defination);
		}
		System.out.println("\nMNT\n");
		for(int i=0;i<mnttab.size();i++)
		{
			System.out.println(mnttab.get(i).name+" "+mnttab.get(i).pp+" "+mnttab.get(i).kp+" "+mnttab.get(i).kpdtp+" "+mnttab.get(i).mdtp);
		}

		br.close();


		BufferedWriter out=new BufferedWriter(new FileWriter("output.txt"));

		for(int i=0;i<mdt.size();i++)
		{
			//System.out.println("HIi");
			//System.out.println(mdt.get(i));
			out.write("\n"+mdt.get(i));
		}

		out.close();
	}




	private void assemble(String line, String name) {
		// TODO Auto-generated method stub
		String[] temp=line.split("[, ]+");
		int index=-1,flag=1;

		String result=temp[0]+"   ";
		for(int i=1;i<temp.length;i++)
		{
			temp[i]=temp[i].replaceAll("&","");
			for(int j=0;j<pntab.size();j++)
			{
				if(pntab.get(j).name.equals(name) && pntab.get(j).parameter.equals(temp[i]))
				{
					index=pntab.get(j).index;
					flag=0;

				}

			}
			if(flag==0)
			{
				result=result+" (P,"+index+")";
			}
			else
			{
				result=result+" (P,"+temp[i]+")";
			}

		}

		mdt.add(result);
	}




	private String updatetable(String line) {
		// TODO Auto-generated method stub

		String name="";
		String[] temp=line.split("[, ]+");
		name=temp[0];
		int kp=0,pp=0,kpdtp=0,mdtp=0;
		boolean flag=true;
		for(int i=1;i<temp.length;i++)
		{
			temp[i]=temp[i].replaceAll("&","");
			if(temp[i].contains("="))
			{
				kp++;
				String[] temp2=temp[i].split("=");
				pntab.add(new Pntab(name,temp2[0],i));
				if(flag)
				{
					kpdtp=kpdtab.size()+1;
					flag=false;
				}
				if(temp2.length>1)
				{
					kpdtab.add(new Kpdtab(temp2[0], temp2[1]));
				}
				else
				{
					kpdtab.add(new Kpdtab(temp2[0],"-" ));

				}
			}
			else
			{
				pp++;
				pntab.add(new Pntab(name,temp[i],i));
			}
		}

		mdtp = mdt.size()+1;
		mnttab.add(new Mnt(name, kp, pp, kpdtp, mdtp));

		return name;
	}




	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

			Macro m=new Macro();
			m.input();
	}

}
