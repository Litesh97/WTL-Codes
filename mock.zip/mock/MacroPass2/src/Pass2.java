import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.StringTokenizer;

class mntTable {
	String name;
	int kp=0,pp=0,kpdtp=0,mdtp=0;
	public mntTable(String name, int pp, int kp, int kpdtp, int mdtp) {
		super();
		this.name = name;
		this.kp = kp;
		this.pp = pp;
		this.kpdtp = kpdtp;
		this.mdtp = mdtp;
	}
	
}

class kpdtab {
	String parametername,defination;

	public kpdtab(String parametername, String defination) {
		super();
		this.parametername = parametername;
		this.defination = defination;
	}
	
}

class mdttab {
	int index;
	String instruction;
	int para1,para2;
	public mdttab(int index, String instruction, int para1, int para2) {
		super();
		this.index = index;
		this.instruction = instruction;
		this.para1 = para1;
		this.para2 = para2;
	}
	
}

class aptabentry 
{
	int index;
	String name;
	public aptabentry(int index, String name) {
		super();
		this.index = index;
		this.name = name;
	}
	
}

class aptabs {
	
	ArrayList<aptabentry> apt = new ArrayList<>();
	String macroname;
	public aptabs(String macroname) {
		super();
		this.macroname = macroname;
	}
	
}






public class Pass2 {

	ArrayList<mntTable> mnt = new ArrayList<>();
	ArrayList<kpdtab> kpd = new ArrayList<>();
	ArrayList<mdttab> mdt = new ArrayList<>();
	ArrayList<String> output = new ArrayList<>();
	ArrayList<aptabs> finalapt = new ArrayList<>();

	
	public void getmnt() throws Exception
	{
		BufferedReader br= new BufferedReader(new FileReader("mnt.txt"));
		String line=null;
		//int i=1;
		String name;
		int pp,kp,kpdp,mdtp;
		while((line=br.readLine())!=null)
		{
			StringTokenizer st=new StringTokenizer(line);
			name=st.nextToken();
			pp=Integer.parseInt(st.nextToken());
			kp=Integer.parseInt(st.nextToken());
			//System.out.println("this is"+kp);
			kpdp=Integer.parseInt(st.nextToken());
			mdtp=Integer.parseInt(st.nextToken());
			mnt.add(new mntTable(name, pp, kp, kpdp, mdtp));
		}
		
		for(int i=0;i<mnt.size();i++)
		{
		//System.out.println(mnt.get(i).name);
		}
		
		br.close();
	}
	
	public void getkpdt() throws Exception
	{
		BufferedReader br= new BufferedReader(new FileReader("kpd.txt"));
		String line=null;
		//int i=1;
		String name,defination;
		while((line=br.readLine())!=null)
		{
			StringTokenizer st=new StringTokenizer(line);
			name=st.nextToken();
			defination=st.nextToken();
			
			kpd.add(new kpdtab(name, defination));
		}
		
		for(int i=0;i<kpd.size();i++)
		{
		System.out.println(kpd.get(i).parametername);
		}
		
		br.close();
	}
	
	public void getmdt() throws Exception
	{
		BufferedReader br= new BufferedReader(new FileReader("mdt.txt"));
		String line=null;
		int k=1,para1=0,para2=0;
		String instruction;
		while((line=br.readLine())!=null)
		{
			String[] temp=line.split("[(), ]+");
			instruction=temp[1];
			if(temp.length>2)
			{
				para1=Integer.parseInt(temp[3]);	
				para2=Integer.parseInt(temp[5]);
				
			}
			mdt.add(new mdttab(k, instruction, para1, para2));
			k++;
		}
		
		for(int i=0;i<mdt.size();i++)
		{
		System.out.println(mdt.get(i).index+"  "+mdt.get(i).instruction);
		}
		
		br.close();
	}
	
	
	
	public void output() throws Exception
	{
		
		BufferedReader br= new BufferedReader(new FileReader("macro.txt"));
		BufferedWriter out=new BufferedWriter(new FileWriter("out.txt"));
		
	String line=null,name=null;
		while((line=br.readLine())!=null)
		{
			assemble(line);
			
			
		}
		
		
		out.close();
		br.close();
	}
	
	
	
	
	private void assemble(String line) {
		// TODO Auto-generated method stub
		
		String[] tokens=line.split("[, ]+");
		String macroname=tokens[0];
		int pp=0,kp=0,mdtp=0,kpdtp=0,numofpara=0;
		
		for(int i=0;i<mnt.size();i++)
		{
			if(macroname.equals(mnt.get(i).name))
			{
				pp=mnt.get(i).pp;
				kp=mnt.get(i).kp;
				mdtp=mnt.get(i).mdtp;
				kpdtp=mnt.get(i).kpdtp;
				numofpara=pp+kp;
				break;
				
			}
		}
		
		aptabs a=new aptabs(macroname);
		for(int i=1;i<tokens.length;i++)
		{
			aptabentry entry=new aptabentry(i, tokens[i]);
			a.apt.add(entry);
		}
		
		if(numofpara>a.apt.size())
		{
			for(int i=kpdtp;i<kpdtp+kp;i++)
			{
				kpdtab entry=kpd.get(i-1);
				if(!entry.defination.equals("-"))
				{
					a.apt.add(new aptabentry(a.apt.size()+1, entry.defination));
				}
			}
		}
		
		finalapt.add(a);
		
		int start=0,end=0;
		int flag=0;
		
		for(int i=0;i<mdt.size();i++)
		{
			if(mdt.get(i).index==mdtp)
			{
				flag=1;
				start=mdtp;
			}
			if(flag==1 && mdt.get(i).instruction.equals("MEND"))
			{
				end=mdt.get(i).index;
				break;
			}
		}
		String result=" ";
		for(int i=start-1;i<end-1;i++)
		{
			mdttab entry= mdt.get(i);
			result=result+entry.instruction+"  "+a.apt.get(entry.para1-1).name+"  "+a.apt.get(entry.para2-1).name+"\n";
		}
		System.out.println("th"+result);
		
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Pass2 p=new Pass2();
		p.getmnt();
		p.getkpdt();
		p.getmdt();
		p.output();
		
	}

}
