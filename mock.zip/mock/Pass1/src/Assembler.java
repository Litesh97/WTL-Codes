import java.io.*;
import java.util.*;
import java.util.Map.Entry;


class Literals
{
	String lit;
	int add;
	public Literals() {
		// TODO Auto-generated constructor stub
		lit=null;
		add=-1;
	}
	public Literals(String lit, int add) {
		super();
		this.lit = lit;
		this.add = add;
	}
	
	
}



public class Assembler {
	int lc=0;
	
	ArrayList<Literals> littab=new ArrayList<Literals>();
	LinkedHashMap<String,Integer> symtab=new LinkedHashMap<String,Integer>();
	HashMap<String,String> IS = new HashMap<>();
	HashMap<String,String> AD = new HashMap<>();
	HashMap<String,String> DL = new HashMap<>();
	HashMap<String,String> CC = new HashMap<>();
	HashMap<String,String> REG = new HashMap<>();
	BufferedWriter out;
	//BufferedReader br=new BufferedReader(new FileReader("test.asm"));
	
	public Assembler()
	{
		
		IS.put("STOP","00");
		IS.put("ADD","01");
		IS.put("SUB","02");
		IS.put("MULT","03");
		IS.put("MOVER","04");
		IS.put("MOVEM","05");
		IS.put("COMP","06");
		IS.put("BC","07");
		IS.put("DIV","08");
		IS.put("READ","09");
		IS.put("PRINT","10");
		
		AD.put("START","01");
		AD.put("STOP","02");
		AD.put("ORIGIN","03");
		AD.put("EQU","04");
		AD.put("LTORG","05");
		
		DL.put("DC","01");
		DL.put("DS","02");
		
		REG.put("AREG","1");
		REG.put("BREG","2");
		REG.put("CREG","3");
		REG.put("DREG","4");
		
		
		CC.put("LT","1");
		CC.put("LE","2");
		CC.put("ET","3");
		CC.put("GT","4");
		CC.put("GE","5");
		CC.put("ANY", "6");
		
	}
	
	public void perform() throws Exception
	{
		
		BufferedReader br=new BufferedReader(new FileReader("test.asm"));
		out=new BufferedWriter(new FileWriter("ic.txt"));
		
		String line=null;
		String[] st;
		while((line=br.readLine())!=null)
		{
			String temp;
			//System.out.println(line);
			 st=line.split("\t");
			for(int i=0;i<st.length;i++)
			{
				System.out.println(st[i]);
			}
			System.out.println();
			System.out.println();
			
			
			
			if((!st[0].equals("")) && (!st[1].equals("EQU")))
			{
				symtab.put(st[0],lc);
				
			}
			if(st[1].equals("LTORG"))
			{
				for(int j=0;j<littab.size();j++)
				{
					//Literals lt=littab.get(j);
					//lt.add=lc;
					
					if(littab.get(j).add==-1)
					{
						Literals l = new Literals();
						l.add=lc;
						l.lit=littab.get(j).lit;
						littab.set(j,l); //replaced
						
						temp="(DL,01) (C,"+l.lit+")\n";
						
						out.write(temp);
						lc++;
					}
					
				}
				//lc--;
			}
			
			if(st[1].equals("START"))
			{
				lc=Integer.parseInt(st[2]);
				temp="(AD,01) (C,"+lc+")\n";
				out.write(temp);
				//lc--;
			}
			if(st[1].equals("END"))
			{
				
				temp="(AD,02)\n";
				out.write(temp);
				//lc--;
				for(int j=0;j<littab.size();j++)
				{
					//Literals lt=littab.get(j);
					//lt.add=lc;
					
					if(littab.get(j).add==-1)
					{
						Literals l = new Literals();
						l.add=lc;
						l.lit=littab.get(j).lit;
						littab.set(j,l);
						
						temp="(DL,01) (C,"+l.lit+")\n";
						out.write(temp);
						lc++;
					}
					
				}
			}
			
			if(st[1].equals("ORIGIN"))
			{
				
				if(st[2].contains("+"))
				{
					String[] ori;
					ori=st[2].split("\\+");
					lc=symtab.get(ori[0])+Integer.parseInt(ori[1]);
					
				}
				else if(st[2].contains("-"))
					{
						String[] ori;
						ori=st[2].split("-");
						lc=symtab.get(ori[0])-Integer.parseInt(ori[1]);
					}
					else
					{
						
						lc=symtab.get(st[2]);
					}
				//lc--;
				
				temp="-----Assembler Directive-----\n";
				out.write(temp);
			}
			
			if(!st[0].equals("") && st[1].equals("EQU"))
			{
				
				int newlc=0;
				if(st[2].contains("+"))
				{
					String[] ori;
					ori=st[2].split("+");
					newlc=symtab.get(ori[0])+Integer.parseInt(ori[1]);
				}
				else if(st[2].contains("-"))
					{
						String[] ori;
						ori=st[2].split("-");
						newlc=symtab.get(ori[0])-Integer.parseInt(ori[1]);
					}
					else
					{
						
						newlc=symtab.get(st[2]);
					}
				
				
				
				symtab.put(st[0],newlc);
				//lc--;
				temp="-----Assembler Directive-----\n";
				out.write(temp);
			}
			
			if(st[1].equals("DS") || st[1].equals("DC"))
			{
				System.out.println("hiiiii");
				symtab.put(st[0],lc);
				if(st[1].equals("DS"))
				{
					int add=Integer.parseInt(st[2]);
					lc=lc+add;
				}
				else
					lc++;
				
				
				temp="(DL,"+DL.get(st[1])+") (C,"+st[2]+")\n";
				out.write(temp);
			}
			
			
			if(IS.containsKey(st[1]))
			{
				String litu;
			if(st.length>=3)
			{
				if(st[3].contains("="))
				{
					 litu=st[3].substring(1, st[3].length());
					// System.out.println(litu);
					/*Literals l=null;
					l.lit=litu;
					l.add=-1;
					littab.add(l);*/
					 littab.add(new Literals(litu,-1));
					 
					 int index=0;
					 for(int i=0;i<littab.size();i++)
					 {
						 if(litu.equals(littab.get(i).lit) && littab.get(i).add==-1)
						 {
						 break;
						 }
						 else
							 index++;
						
					 }
					 
					 st[2]=st[2].substring(0,st[2].length()-1);
					 System.out.println("my"+st[2]);
					if(REG.containsKey(st[2]))
					{
						System.out.println("hiiiii"+st[2]);
						
					temp="(IS,"+IS.get(st[1])+") ("+REG.get(st[2])+") (L,"+index+")\n";
					}
					else
					{
						temp="(IS,"+IS.get(st[1])+") ("+CC.get(st[2])+") (L,"+index+")\n" ;

					}
				}
				else
				{
					symtab.put(st[3],-1);
					int index=0;
					for(String key:symtab.keySet())
					{
						if(key.equals(st[3]))
							break;
						index++;
					}
					st[2]=st[2].substring(0,st[2].length()-1);
					if(REG.containsKey(st[2]))
					{
					temp="(IS,"+IS.get(st[1])+") ("+REG.get(st[2])+") (S,"+index+")\n";
					}
					else
					{
						temp="(IS,"+IS.get(st[1])+") ("+CC.get(st[2])+") (S,"+index+")\n" ;

					}
					
				}
				out.write(temp);
			}
				
				if(st[1].equals("STOP"))
				{
					temp="(IS,00)\n";
					out.write(temp);
				}
				
				
				lc++;
			}
			
			
			
			
			
			
			//lc++;
			//System.out.println(lc);
			//System.out.println();
		}
		
		
		
		for (Entry<String, Integer> sc:symtab.entrySet())
		{
			System.out.println(" "+sc.getKey()+"   "+sc.getValue());
		}
		
		System.out.println();
		
		for(int i=0;i<littab.size();i++)
		{
			System.out.println(" "+littab.get(i).lit+"   "+littab.get(i).add);
		}
		
		
		br.close();
		out.close();
	}
	
	
	
	
	
	
	
	
	
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			
			Assembler a=new Assembler();
			a.perform();
			System.out.println("LC"+a.lc);
	}

}
