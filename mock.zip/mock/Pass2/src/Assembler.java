import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import javax.crypto.Mac;

public class Assembler {

	ArrayList<String> symtab= new ArrayList<>();
	ArrayList<String> litab= new ArrayList<>();
	ArrayList<String> Machinecode= new ArrayList<>();

	public void setSymbol() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("symtab.txt"));

		String Line=null;
		while((Line=br.readLine())!=null)
		{
			String token[]=Line.split("\t");
			symtab.add(token[1]);
			//System.out.println(token[1]);
		}




		br.close();

	}

	public void setLiteral() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("littab.txt"));

		String Line=null;
		while((Line=br.readLine())!=null)
		{
			String token[]=Line.split("\t");
			litab.add(token[1]);
			//System.out.println(token[1]);
		}




		br.close();

	}

	public void modify() throws Exception
	{
		BufferedReader br=new BufferedReader(new FileReader("intermediate.txt"));

		String Line=null;
		while((Line=br.readLine())!=null)
		{
			if(Line.contains("AD"))
			{
				continue;
			}
			if(Line.contains("----------"))
			{
			String machinecode="";
			String[] code=Line.split("----------");
			machinecode=machinecode+code[1]+")";
			String[] tokens=code[0].split("[(), ]+");
			System.out.println();
			for(int z=0;z<tokens.length;z++)
			{
				System.out.print(tokens[z]+"\t");
			}
			System.out.println();
			String temp=assemble(tokens);
			machinecode=machinecode+temp;
			Machinecode.add(machinecode);
			}
		}

		br.close();

		BufferedWriter out=new BufferedWriter(new FileWriter("machine.o"));

		for(int i=0;i<Machinecode.size();i++)
		{
			out.write(Machinecode.get(i)+"\n");
			System.out.println(Machinecode.get(i)+" \n");
		}



		out.close();
	}







	private String assemble(String[] tokens) {
		// TODO Auto-generated method stub
		String returnstring="";
		if(tokens[2].equals("00"))
		{
			returnstring="00 0 000";
		}
		else if(tokens[1].equals("DL"))
		{
			if(tokens[2].equals("02"))
			{

			}
			else
			{
				returnstring="00 0 00"+tokens[4];
			}
		}
		else
		{
			if(tokens[4].equals("L"))
			{
				returnstring=tokens[2]+" "+tokens[3]+" "+litab.get(Integer.parseInt(tokens[5])-1);
			}
			else
			{
				returnstring=tokens[2]+" "+tokens[3]+" "+symtab.get(Integer.parseInt(tokens[5])-1);
			}
		}


		return returnstring;
	}

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

		Assembler a=new Assembler();
		a.setSymbol();
		a.setLiteral();
		a.modify();

	}

}
